﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _184517CheckerBoardDrawing
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            for (int j = 0; j <= 7; j++)
            {
                for (int i = 0; i <= 7; i++) 
                {
                    Rectangle r = new Rectangle();
                    r.Height = 100;
                    r.Width = 100;
                    if ((i + j) % 2 == 0)
                    {
                        r.Fill = Brushes.Pink;
                    }
                    else
                    {
                        r.Fill = Brushes.Cyan;
                    }
                    canvas.Children.Add(r);
                    Canvas.SetTop(r, j * 100);
                    Canvas.SetLeft(r, i * 100);
                }
              
            }
        }
    }
}
